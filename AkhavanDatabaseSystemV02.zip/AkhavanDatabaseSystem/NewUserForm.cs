﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class NewUserForm : Form
    {
        string oldPassword, newPassword, confirmPassword, originalPassword,
            userName;

        private void exitButton_Click(object sender, EventArgs e)
        {
            LogInUserControl.GetUserName = LogInUserControl.Username;
            var loginForm = new LogInForm();
            loginForm.Show();
            this.Close();
        }

        private void userBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.userBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.userDataSet);

        }

        public NewUserForm()
        {
            InitializeComponent();
        }

        private void userBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.userBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.userDataSet);

        }
        private void ChangePasswordButton_Click(object sender, EventArgs e)
        {
            oldPassword = oldPasswordTextBox.Text;
            newPassword = newPassWordTextBox.Text;
            confirmPassword = confirmPasswordTextBox.Text;
            originalPassword = LogInUserControl.PassWord;
            userName = LogInUserControl.Username;
            if (!oldPassword.Equals(originalPassword))
            {
                newUserErrorLabel.Text = userName;
            }
            else
            {
                if(!newPassword.Equals(confirmPassword))
                {
                    newUserErrorLabel.Text = "Passwords do not match.";
                }
                else
                {
                    newUserErrorLabel.ForeColor = Color.Green;
                    newUserErrorLabel.Text = " Succesfull password change!";

                    this.userTableAdapter.upDatePassword(newPassword, userName);
                    this.Validate();
                    this.userBindingSource.EndEdit();
                    this.tableAdapterManager.UpdateAll(this.userDataSet);
                }
            }
        }
    }
}
