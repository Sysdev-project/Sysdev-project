﻿namespace AkhavanDatabaseSystem
{
    partial class HomeUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.welcomeUserLabel = new System.Windows.Forms.Label();
            this.storeInventoryTitleLabel = new System.Windows.Forms.Label();
            this.StoreInventoryNumber = new System.Windows.Forms.Label();
            this.lowStockLabel = new System.Windows.Forms.Label();
            this.currentLowStockItemsCountLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.storeInventoryPictureBox = new System.Windows.Forms.PictureBox();
            this.databaseDataSet = new AkhavanDatabaseSystem.DatabaseDataSet();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productTableAdapter = new AkhavanDatabaseSystem.DatabaseDataSetTableAdapters.productTableAdapter();
            this.tableAdapterManager = new AkhavanDatabaseSystem.DatabaseDataSetTableAdapters.TableAdapterManager();
            this.userDataSet = new AkhavanDatabaseSystem.UserDataSet();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userTableAdapter = new AkhavanDatabaseSystem.UserDataSetTableAdapters.UserTableAdapter();
            this.tableAdapterManager1 = new AkhavanDatabaseSystem.UserDataSetTableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storeInventoryPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // welcomeUserLabel
            // 
            this.welcomeUserLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeUserLabel.Location = new System.Drawing.Point(62, 57);
            this.welcomeUserLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.welcomeUserLabel.Name = "welcomeUserLabel";
            this.welcomeUserLabel.Size = new System.Drawing.Size(451, 32);
            this.welcomeUserLabel.TabIndex = 0;
            this.welcomeUserLabel.Text = "Welcome H Aime Bruno 1846278";
            // 
            // storeInventoryTitleLabel
            // 
            this.storeInventoryTitleLabel.BackColor = System.Drawing.Color.LightCyan;
            this.storeInventoryTitleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.storeInventoryTitleLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.storeInventoryTitleLabel.Location = new System.Drawing.Point(62, 145);
            this.storeInventoryTitleLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.storeInventoryTitleLabel.Name = "storeInventoryTitleLabel";
            this.storeInventoryTitleLabel.Size = new System.Drawing.Size(192, 25);
            this.storeInventoryTitleLabel.TabIndex = 1;
            this.storeInventoryTitleLabel.Text = "Store Inventory";
            this.storeInventoryTitleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // StoreInventoryNumber
            // 
            this.StoreInventoryNumber.BackColor = System.Drawing.Color.Teal;
            this.StoreInventoryNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.StoreInventoryNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StoreInventoryNumber.ForeColor = System.Drawing.Color.White;
            this.StoreInventoryNumber.Location = new System.Drawing.Point(62, 170);
            this.StoreInventoryNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.StoreInventoryNumber.Name = "StoreInventoryNumber";
            this.StoreInventoryNumber.Size = new System.Drawing.Size(111, 72);
            this.StoreInventoryNumber.TabIndex = 3;
            this.StoreInventoryNumber.Text = "1267 Products";
            this.StoreInventoryNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lowStockLabel
            // 
            this.lowStockLabel.BackColor = System.Drawing.Color.Teal;
            this.lowStockLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowStockLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lowStockLabel.ForeColor = System.Drawing.Color.White;
            this.lowStockLabel.Location = new System.Drawing.Point(321, 170);
            this.lowStockLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lowStockLabel.Name = "lowStockLabel";
            this.lowStockLabel.Size = new System.Drawing.Size(111, 72);
            this.lowStockLabel.TabIndex = 6;
            this.lowStockLabel.Text = "30 Products";
            this.lowStockLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // currentLowStockItemsCountLabel
            // 
            this.currentLowStockItemsCountLabel.BackColor = System.Drawing.Color.LightCyan;
            this.currentLowStockItemsCountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.currentLowStockItemsCountLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentLowStockItemsCountLabel.Location = new System.Drawing.Point(321, 145);
            this.currentLowStockItemsCountLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.currentLowStockItemsCountLabel.Name = "currentLowStockItemsCountLabel";
            this.currentLowStockItemsCountLabel.Size = new System.Drawing.Size(192, 25);
            this.currentLowStockItemsCountLabel.TabIndex = 4;
            this.currentLowStockItemsCountLabel.Text = "Items in Low Stock";
            this.currentLowStockItemsCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::AkhavanDatabaseSystem.Properties.Resources.alertIcon;
            this.pictureBox1.Location = new System.Drawing.Point(431, 170);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(82, 72);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // storeInventoryPictureBox
            // 
            this.storeInventoryPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.storeInventoryPictureBox.Image = global::AkhavanDatabaseSystem.Properties.Resources.storeInvIcon;
            this.storeInventoryPictureBox.Location = new System.Drawing.Point(172, 170);
            this.storeInventoryPictureBox.Margin = new System.Windows.Forms.Padding(2);
            this.storeInventoryPictureBox.Name = "storeInventoryPictureBox";
            this.storeInventoryPictureBox.Size = new System.Drawing.Size(82, 72);
            this.storeInventoryPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.storeInventoryPictureBox.TabIndex = 2;
            this.storeInventoryPictureBox.TabStop = false;
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "DatabaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "product";
            this.productBindingSource.DataSource = this.databaseDataSet;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.productTableAdapter = this.productTableAdapter;
            this.tableAdapterManager.UpdateOrder = AkhavanDatabaseSystem.DatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // userDataSet
            // 
            this.userDataSet.DataSetName = "UserDataSet";
            this.userDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "User";
            this.userBindingSource.DataSource = this.userDataSet;
            // 
            // userTableAdapter
            // 
            this.userTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.UpdateOrder = AkhavanDatabaseSystem.UserDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager1.UserTableAdapter = this.userTableAdapter;
            // 
            // HomeUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.Controls.Add(this.lowStockLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.currentLowStockItemsCountLabel);
            this.Controls.Add(this.StoreInventoryNumber);
            this.Controls.Add(this.storeInventoryPictureBox);
            this.Controls.Add(this.storeInventoryTitleLabel);
            this.Controls.Add(this.welcomeUserLabel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HomeUserControl";
            this.Size = new System.Drawing.Size(587, 546);
            this.Load += new System.EventHandler(this.HomeUserControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storeInventoryPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label welcomeUserLabel;
        private System.Windows.Forms.Label storeInventoryTitleLabel;
        private System.Windows.Forms.PictureBox storeInventoryPictureBox;
        private System.Windows.Forms.Label StoreInventoryNumber;
        private System.Windows.Forms.Label lowStockLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label currentLowStockItemsCountLabel;
        private DatabaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource productBindingSource;
        private DatabaseDataSetTableAdapters.productTableAdapter productTableAdapter;
        private DatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private UserDataSet userDataSet;
        private System.Windows.Forms.BindingSource userBindingSource;
        private UserDataSetTableAdapters.UserTableAdapter userTableAdapter;
        private UserDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
    }
}
