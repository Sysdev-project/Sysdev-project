﻿namespace AkhavanDatabaseSystem
{


    public partial class DatabaseDataSet
    {
    }
}
namespace AkhavanDatabaseSystem {
    
    
    public partial class DatabaseDataSet {
    }
}
