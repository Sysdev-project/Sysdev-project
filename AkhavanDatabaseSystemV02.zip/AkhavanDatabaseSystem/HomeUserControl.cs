﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class HomeUserControl : UserControl
    {
        public HomeUserControl()
        {
            InitializeComponent();
        }

        private void HomeUserControl_Load(object sender, EventArgs e)
        {
            int numberOfRows = (int)this.productTableAdapter.productCount();
            int lowStockRows = (int)this.productTableAdapter.lowStockCount();
            string username = (string)this.userTableAdapter.userNameSearch(LogInUserControl.Username);
            string lastname = (string)this.userTableAdapter.lastNameSearch(LogInUserControl.Username);
            Int32 employeeNumber = (Int32)this.userTableAdapter.empNumberSearch(LogInUserControl.Username);
            
            StoreInventoryNumber.Text = numberOfRows + "\n Products";
            lowStockLabel.Text = lowStockRows + "\n Products";
            welcomeUserLabel.Text = "Welcome " + " " +
                username + " " + lastname + " " + employeeNumber.ToString() + ".";
        }

        private void productBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.databaseDataSet);

        }
    }
}
