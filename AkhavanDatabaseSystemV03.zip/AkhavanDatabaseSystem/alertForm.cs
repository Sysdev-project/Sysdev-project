﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class AlertForm : Form
    {
        public AlertForm()
        {
            InitializeComponent();
        }

        //Getter for the alert Label
        public Label getLabel()
        {
            return alertLabel;
        }

        //Getter for the picture Box.
        public PictureBox getPictureBox()
        {
            return checkMarkPictureBox;
        }

        //Handler for the OK button
        private void okButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
