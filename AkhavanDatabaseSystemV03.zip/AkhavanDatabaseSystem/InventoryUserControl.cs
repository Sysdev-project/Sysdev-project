﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class InventoryUserControl : UserControl
    {
        //Get the label and picture box from AlertForm
        private AlertForm alertForm = new AlertForm();
        private Label alertLabel;
        private PictureBox alertPic;
        public InventoryUserControl()
        {
            InitializeComponent();
        }

        private void InventoryUserControl_Load(object sender, EventArgs e)
        {
            //Fill the DataGridView with the table everytime this user control opens
            this.productTableAdapter1.Fill(this.database1DataSet.product);
        }

        //Handler for the search button
        private void searchByNameRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            //Depending on the radio button checked
            //change the text in the search text box to the specified one
            //change color of the text to silver
            if (searchByNameRadioBtn.Checked)
            {
                searchTextBox.Text = "Item Name";
                searchTextBox.ForeColor = Color.Silver;
            }
            else
            {
                searchTextBox.Text = "Item Number";
                searchTextBox.ForeColor = Color.Silver;
            }
        }

        //Handler for when the cursor is placed in the search text box
        private void searchTextBox_Enter(object sender, EventArgs e)
        {
            if ((searchTextBox.Text == "Item Name" || searchTextBox.Text == "Item Number") && searchTextBox.ForeColor == Color.Silver)
            {
                searchTextBox.Text = "";
                searchTextBox.ForeColor = Color.Black;
            }

        }

        //Handler for when the cursor leaves the search text box
        //Sets the default inside the search box based on the cursor's position
        private void searchTextBox_Leave(object sender, EventArgs e)
        {
            if (searchTextBox.Text == "")
            {
                if (searchByNameRadioBtn.Checked)
                {
                    searchTextBox.Text = "Item Name";
                    searchTextBox.ForeColor = Color.Silver;
                }
                else
                {
                    showError();
                    searchTextBox.Text = "Item Number";
                    searchTextBox.ForeColor = Color.Silver;
                }
            }
        }

        //Handler for the search button
        private void searchBtn_Click(object sender, EventArgs e)
        {
            //If search by Number radio button is checked
            if(searchByItemNumberBtn.Checked)
            {
                long n = 0;
                bool isLong = long.TryParse(searchTextBox.Text.ToString(), out n);
                if(isLong == false)
                {
                    showError();
                    alertLabel.Text = "Value must be numeric!";
                    alertForm.Show();
                }
                else
                {
                    //Get the code entered in the search box
                    long inventorySearchCode = long.Parse(searchTextBox.Text.ToString());
                    //Search the database for a row with the corresponding barcode
                    //Display the results
                    this.productTableAdapter1.searchByNumber(
                        this.database1DataSet.product, inventorySearchCode);
                }
                
            }
            else
            {
                //Here search the database for a row with the corresponding string
                //Display the results
                string inventorySearchName = searchTextBox.Text.ToString();
                this.productTableAdapter1.searchByName(
                    this.database1DataSet.product, inventorySearchName);
            }
        }

        //Handler for the cancel search button
        private void cancelSearchButton_Click(object sender, EventArgs e)
        {
            //Display the entire databse table
            this.productTableAdapter1.Fill(this.database1DataSet.product);
        }

        //Handler for the add new product button
        private void addProductButton_Click(object sender, EventArgs e)
        {
            //this.productBindingSource.
            this.productDataGridView.FirstDisplayedScrollingRowIndex =
                this.productDataGridView.RowCount - 1;

            this.productDataGridView.BeginEdit(true);
        }

        //Handler for the delete product button
        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (productDataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in this.productDataGridView.SelectedRows)
                {
                    if (row.Selected)
                    {
                        productDataGridView.Rows.Remove(row);
                    }
                }
            }
            else
            {
                alertLabel.Text = "No wors selected!";
                alertForm.Show();
            }
                
        }

        //Handler for the save button
        private void saveChangesButton_Click(object sender, EventArgs e)
        {
            //Saves changes made to the table back to the database
            this.productTableAdapter1.Update(this.database1DataSet.product);
            AlertForm alertForm = new AlertForm();
            alertForm.Show();
        }

        //method to set properties for the alert label properties inside alert form
        void showError ()
        {
            alertLabel = alertForm.getLabel();
            alertPic = alertForm.getPictureBox();
            alertPic.Visible = false; //This hides the picture box
            alertLabel.ForeColor = Color.Red; //Sets the color of the message to red
        }
    }
}
