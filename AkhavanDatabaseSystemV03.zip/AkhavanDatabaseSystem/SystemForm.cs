﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class SystemForm : Form
    {
        public SystemForm()
        {
            InitializeComponent();

        }

        //Handler for the Home button
        private void homeBtn_Click(object sender, EventArgs e)
        {
            //show the home user Control form
            homeUserControl2.BringToFront();
        }

        //Handler for the inventory button
        private void inventoryBtn_Click(object sender, EventArgs e)
        {
            //show the inventory user Control form
            inventoryUserControl1.BringToFront();
        }

        //Handler for the reports button
        private void reportsBtn_Click(object sender, EventArgs e)
        {
            //show the reports user control
            reportsUserControl1.BringToFront();
        }

        //Handler for the logout button
        private void logoutBtn_Click(object sender, EventArgs e)
        {
            //Get a new instace of the login form
            //Show this login form instance
            //Close the current form on screen
            var newLogIn = new LogInForm();
            newLogIn.Show();
            this.Close();
        }
    }
}
