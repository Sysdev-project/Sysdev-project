﻿namespace AkhavanDatabaseSystem
{


    partial class User_CredentialDataSet
    {
    }
}

namespace AkhavanDatabaseSystem.User_CredentialDataSetTableAdapters {
    
    
    public partial class User_CredentialTableAdapter {
    }
}
