﻿namespace AkhavanDatabaseSystem
{


    partial class UserDataSet
    {
    }
}

namespace AkhavanDatabaseSystem.UserDataSetTableAdapters {
    
    
    public partial class UserTableAdapter {
    }
}
