﻿namespace AkhavanDatabaseSystem
{
    partial class InventoryUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.radioBtnPanel = new System.Windows.Forms.Panel();
            this.searchByItemNumberBtn = new System.Windows.Forms.RadioButton();
            this.searchByNameRadioBtn = new System.Windows.Forms.RadioButton();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.cancelSearchButton = new System.Windows.Forms.Button();
            this.addProductButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.saveChangesButton = new System.Windows.Forms.Button();
            this.productDataGridView = new System.Windows.Forms.DataGridView();
            this.barcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netWTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.packDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.casesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventoryQTYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oNOrderQTYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet = new AkhavanDatabaseSystem.Database1DataSet();
            this.productBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.productTableAdapter1 = new AkhavanDatabaseSystem.Database1DataSetTableAdapters.productTableAdapter();
            this.tableAdapterManager1 = new AkhavanDatabaseSystem.Database1DataSetTableAdapters.TableAdapterManager();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet = new AkhavanDatabaseSystem.DatabaseDataSet();
            this.productTableAdapter = new AkhavanDatabaseSystem.DatabaseDataSetTableAdapters.productTableAdapter();
            this.tableAdapterManager = new AkhavanDatabaseSystem.DatabaseDataSetTableAdapters.TableAdapterManager();
            this.radioBtnPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // radioBtnPanel
            // 
            this.radioBtnPanel.Controls.Add(this.searchByItemNumberBtn);
            this.radioBtnPanel.Controls.Add(this.searchByNameRadioBtn);
            this.radioBtnPanel.Location = new System.Drawing.Point(116, 2);
            this.radioBtnPanel.Margin = new System.Windows.Forms.Padding(2);
            this.radioBtnPanel.Name = "radioBtnPanel";
            this.radioBtnPanel.Size = new System.Drawing.Size(369, 38);
            this.radioBtnPanel.TabIndex = 0;
            // 
            // searchByItemNumberBtn
            // 
            this.searchByItemNumberBtn.AutoSize = true;
            this.searchByItemNumberBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchByItemNumberBtn.Location = new System.Drawing.Point(183, 16);
            this.searchByItemNumberBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchByItemNumberBtn.Name = "searchByItemNumberBtn";
            this.searchByItemNumberBtn.Size = new System.Drawing.Size(186, 20);
            this.searchByItemNumberBtn.TabIndex = 1;
            this.searchByItemNumberBtn.Text = "Search By Item Number";
            this.searchByItemNumberBtn.UseVisualStyleBackColor = true;
            // 
            // searchByNameRadioBtn
            // 
            this.searchByNameRadioBtn.AutoSize = true;
            this.searchByNameRadioBtn.Checked = true;
            this.searchByNameRadioBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchByNameRadioBtn.Location = new System.Drawing.Point(2, 16);
            this.searchByNameRadioBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchByNameRadioBtn.Name = "searchByNameRadioBtn";
            this.searchByNameRadioBtn.Size = new System.Drawing.Size(171, 20);
            this.searchByNameRadioBtn.TabIndex = 0;
            this.searchByNameRadioBtn.TabStop = true;
            this.searchByNameRadioBtn.Text = "Search By Item Name";
            this.searchByNameRadioBtn.UseVisualStyleBackColor = true;
            this.searchByNameRadioBtn.CheckedChanged += new System.EventHandler(this.searchByNameRadioBtn_CheckedChanged);
            // 
            // searchTextBox
            // 
            this.searchTextBox.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTextBox.ForeColor = System.Drawing.Color.Silver;
            this.searchTextBox.Location = new System.Drawing.Point(6, 58);
            this.searchTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(376, 29);
            this.searchTextBox.TabIndex = 1;
            this.searchTextBox.Text = "Item Name";
            this.searchTextBox.Enter += new System.EventHandler(this.searchTextBox_Enter);
            this.searchTextBox.Leave += new System.EventHandler(this.searchTextBox_Leave);
            // 
            // searchBtn
            // 
            this.searchBtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBtn.Location = new System.Drawing.Point(393, 56);
            this.searchBtn.Margin = new System.Windows.Forms.Padding(2);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(92, 31);
            this.searchBtn.TabIndex = 2;
            this.searchBtn.Text = "Search Item";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // cancelSearchButton
            // 
            this.cancelSearchButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelSearchButton.Location = new System.Drawing.Point(499, 56);
            this.cancelSearchButton.Margin = new System.Windows.Forms.Padding(2);
            this.cancelSearchButton.Name = "cancelSearchButton";
            this.cancelSearchButton.Size = new System.Drawing.Size(110, 31);
            this.cancelSearchButton.TabIndex = 5;
            this.cancelSearchButton.Text = "Cancel Search";
            this.cancelSearchButton.UseVisualStyleBackColor = true;
            this.cancelSearchButton.Click += new System.EventHandler(this.cancelSearchButton_Click);
            // 
            // addProductButton
            // 
            this.addProductButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addProductButton.Location = new System.Drawing.Point(141, 414);
            this.addProductButton.Name = "addProductButton";
            this.addProductButton.Size = new System.Drawing.Size(112, 30);
            this.addProductButton.TabIndex = 9;
            this.addProductButton.Text = "Add New Product";
            this.addProductButton.UseVisualStyleBackColor = true;
            this.addProductButton.Click += new System.EventHandler(this.addProductButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteButton.Location = new System.Drawing.Point(259, 414);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(99, 30);
            this.deleteButton.TabIndex = 10;
            this.deleteButton.Text = "Delete Product";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // saveChangesButton
            // 
            this.saveChangesButton.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveChangesButton.Location = new System.Drawing.Point(364, 414);
            this.saveChangesButton.Name = "saveChangesButton";
            this.saveChangesButton.Size = new System.Drawing.Size(99, 30);
            this.saveChangesButton.TabIndex = 11;
            this.saveChangesButton.Text = "Save changes";
            this.saveChangesButton.UseVisualStyleBackColor = true;
            this.saveChangesButton.Click += new System.EventHandler(this.saveChangesButton_Click);
            // 
            // productDataGridView
            // 
            this.productDataGridView.AutoGenerateColumns = false;
            this.productDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.productDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.productDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.productDataGridView.ColumnHeadersHeight = 39;
            this.productDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.barcodeDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.netWTDataGridViewTextBoxColumn,
            this.packDataGridViewTextBoxColumn,
            this.casesDataGridViewTextBoxColumn,
            this.inventoryQTYDataGridViewTextBoxColumn,
            this.oNOrderQTYDataGridViewTextBoxColumn});
            this.productDataGridView.DataSource = this.productBindingSource2;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.productDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.productDataGridView.GridColor = System.Drawing.Color.White;
            this.productDataGridView.Location = new System.Drawing.Point(6, 92);
            this.productDataGridView.Name = "productDataGridView";
            this.productDataGridView.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.productDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.productDataGridView.RowHeadersWidth = 10;
            this.productDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.productDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.productDataGridView.RowTemplate.DividerHeight = 4;
            this.productDataGridView.RowTemplate.Height = 40;
            this.productDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.productDataGridView.Size = new System.Drawing.Size(603, 316);
            this.productDataGridView.TabIndex = 11;
            // 
            // barcodeDataGridViewTextBoxColumn
            // 
            this.barcodeDataGridViewTextBoxColumn.DataPropertyName = "Barcode";
            this.barcodeDataGridViewTextBoxColumn.HeaderText = "Barcode";
            this.barcodeDataGridViewTextBoxColumn.Name = "barcodeDataGridViewTextBoxColumn";
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "Product Name";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "Product Name";
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            // 
            // netWTDataGridViewTextBoxColumn
            // 
            this.netWTDataGridViewTextBoxColumn.DataPropertyName = "Net WT_";
            this.netWTDataGridViewTextBoxColumn.HeaderText = "Net WT_";
            this.netWTDataGridViewTextBoxColumn.Name = "netWTDataGridViewTextBoxColumn";
            // 
            // packDataGridViewTextBoxColumn
            // 
            this.packDataGridViewTextBoxColumn.DataPropertyName = "Pack";
            this.packDataGridViewTextBoxColumn.HeaderText = "Pack";
            this.packDataGridViewTextBoxColumn.Name = "packDataGridViewTextBoxColumn";
            // 
            // casesDataGridViewTextBoxColumn
            // 
            this.casesDataGridViewTextBoxColumn.DataPropertyName = "Cases";
            this.casesDataGridViewTextBoxColumn.HeaderText = "Cases";
            this.casesDataGridViewTextBoxColumn.Name = "casesDataGridViewTextBoxColumn";
            // 
            // inventoryQTYDataGridViewTextBoxColumn
            // 
            this.inventoryQTYDataGridViewTextBoxColumn.DataPropertyName = "Inventory QTY";
            this.inventoryQTYDataGridViewTextBoxColumn.HeaderText = "Inventory QTY";
            this.inventoryQTYDataGridViewTextBoxColumn.Name = "inventoryQTYDataGridViewTextBoxColumn";
            // 
            // oNOrderQTYDataGridViewTextBoxColumn
            // 
            this.oNOrderQTYDataGridViewTextBoxColumn.DataPropertyName = "ON Order QTY";
            this.oNOrderQTYDataGridViewTextBoxColumn.HeaderText = "ON Order QTY";
            this.oNOrderQTYDataGridViewTextBoxColumn.Name = "oNOrderQTYDataGridViewTextBoxColumn";
            // 
            // productBindingSource2
            // 
            this.productBindingSource2.DataMember = "product";
            this.productBindingSource2.DataSource = this.database1DataSetBindingSource;
            // 
            // database1DataSetBindingSource
            // 
            this.database1DataSetBindingSource.DataSource = this.database1DataSet;
            this.database1DataSetBindingSource.Position = 0;
            // 
            // database1DataSet
            // 
            this.database1DataSet.DataSetName = "Database1DataSet";
            this.database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productBindingSource1
            // 
            this.productBindingSource1.DataMember = "product";
            this.productBindingSource1.DataSource = this.database1DataSet;
            // 
            // productTableAdapter1
            // 
            this.productTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.productTableAdapter = this.productTableAdapter1;
            this.tableAdapterManager1.UpdateOrder = AkhavanDatabaseSystem.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "product";
            this.productBindingSource.DataSource = this.databaseDataSet;
            // 
            // databaseDataSet
            // 
            this.databaseDataSet.DataSetName = "DatabaseDataSet";
            this.databaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.productTableAdapter = this.productTableAdapter;
            this.tableAdapterManager.UpdateOrder = AkhavanDatabaseSystem.DatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // InventoryUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.Controls.Add(this.productDataGridView);
            this.Controls.Add(this.saveChangesButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.addProductButton);
            this.Controls.Add(this.cancelSearchButton);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.radioBtnPanel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "InventoryUserControl";
            this.Size = new System.Drawing.Size(612, 452);
            this.Load += new System.EventHandler(this.InventoryUserControl_Load);
            this.radioBtnPanel.ResumeLayout(false);
            this.radioBtnPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel radioBtnPanel;
        private System.Windows.Forms.RadioButton searchByItemNumberBtn;
        private System.Windows.Forms.RadioButton searchByNameRadioBtn;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.Button searchBtn;
        private DatabaseDataSet databaseDataSet;
        private System.Windows.Forms.BindingSource productBindingSource;
        private DatabaseDataSetTableAdapters.productTableAdapter productTableAdapter;
        private DatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button cancelSearchButton;
        private System.Windows.Forms.Button addProductButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button saveChangesButton;
        private Database1DataSet database1DataSet;
        private System.Windows.Forms.BindingSource productBindingSource1;
        private Database1DataSetTableAdapters.productTableAdapter productTableAdapter1;
        private Database1DataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView productDataGridView;
        private System.Windows.Forms.BindingSource database1DataSetBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn barcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netWTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn packDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn casesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryQTYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oNOrderQTYDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource productBindingSource2;
    }
}
