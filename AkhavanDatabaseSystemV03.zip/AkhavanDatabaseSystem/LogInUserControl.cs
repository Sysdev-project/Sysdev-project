﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting.Channels;

namespace AkhavanDatabaseSystem
{
    public partial class LogInUserControl : UserControl
    {
        private static string password, username;
        private static TextBox userTextBox;
        public LogInUserControl()
        {
            InitializeComponent();
        }
        private void usernameTextBox_Enter(object sender, EventArgs e)
        {
            if(usernameTextBox.Text == "Employee Id" && 
                usernameTextBox.ForeColor == Color.Silver)
            {
                usernameTextBox.Text = "";
                loginErrorLabel.Text = " ";
                usernameTextBox.ForeColor = Color.Black;
            }
        }

        private void usernameTextBox_Leave(object sender, EventArgs e)
        {
            if (usernameTextBox.Text == "")
            {
                usernameTextBox.ForeColor = Color.Silver;
                usernameTextBox.Text = "Employee Id";
                loginErrorLabel.Text = " ";
            }
        }

        private void passwordTextBox_Enter(object sender, EventArgs e)
        {
            if(passwordTextBox.Text == "Password" && passwordTextBox.ForeColor == Color.Silver)
            {
                passwordTextBox.Text = " ";
                loginErrorLabel.Text = " ";
                passwordTextBox.ForeColor = Color.Black;
                passwordTextBox.PasswordChar = '*';
            }
        }

        private void passwordTextBox_Leave(object sender, EventArgs e)
        {
            if (passwordTextBox.Text == "")
            {
                passwordTextBox.ForeColor = Color.Silver;
                passwordTextBox.Text = "Password";
                loginErrorLabel.Text = " ";
                passwordTextBox.PasswordChar = '\0';
            }
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            /*  This is where username and password validation occurs (only allow the code below to occur if the values match)
                Checks that both the userName & password exist in the database
                If the password entered by the user is the default one, prompt to change it
                else check that the password is correct, then allow access or display error message
            */
            username = usernameTextBox.Text;
            bool isValidUsername = this.user_CredentialTableAdapter.usernameSearchCount(
                username) > 0;
            password = (string)this.user_CredentialTableAdapter.passwordSearch(
                username);

            string genericPassword = "P@ssword!23";

            if(usernameTextBox.TextLength == 0 || 
                passwordTextBox.TextLength == 0)
            {
                loginErrorLabel.Text = "Incorrect username or password.";
            }
            else
            {
                if (isValidUsername == false)
                {
                    loginErrorLabel.Text = "Incorrect username or password.";
                }
                else
                {
                    if (!passwordTextBox.Text.Equals(password))
                    {
                        loginErrorLabel.Text = "Incorrect password. Try again.";
                    }
                    else
                    {
                        if (password.Equals(genericPassword))
                        {
                            loginErrorLabel.Text = " ";
                            var newUserForm = new NewUserForm();
                            newUserForm.Show();
                            var parent = ParentForm as LogInForm;
                            parent.Close();
                        }
                        else
                        {
                            loginErrorLabel.Text = " ";
                            var newSystemForm = new SystemForm();
                            newSystemForm.Show();
                            var parent = ParentForm as LogInForm;
                            parent.Close();
                        }
                    }
                }

            }

        }

        //Property to get and/or set the password entered by the user
        public static string PassWord
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }

        //Property to get and/or set the username entered by the user
        public static string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }


        //Exit button handler
        private void exitAppBtn_Click(object sender, EventArgs e)
        {
            //Closes the application
            Environment.Exit(0);
        }

        private void LogInUserControl_Load(object sender, EventArgs e)
        {
            userTextBox = usernameTextBox;
        }

        //Handler for "Forgot Password" Link Label
        //Opens a message dialog box
        private void forgotLinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Please constact your system administrator for help!");
        }
    }
}
