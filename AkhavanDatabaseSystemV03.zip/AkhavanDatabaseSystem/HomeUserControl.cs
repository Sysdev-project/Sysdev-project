﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AkhavanDatabaseSystem
{
    public partial class HomeUserControl : UserControl
    {
        public HomeUserControl()
        {
            InitializeComponent();
        }

        private void HomeUserControl_Load(object sender, EventArgs e)
        {
            //Number of all products data base
            int numberOfRows = (int)this.productTableAdapter.productCount();

            //Number of prodcts in low stock (>50 packs)
            int lowStockRows = (int)this.productTableAdapter.lowStockCount();

            //Logged in user's first name
            string firstName = (string)this.user_CredentialTableAdapter.firstNameSearch(LogInUserControl.Username);

            //Logged in user's last name
            string lastName = (string)this.user_CredentialTableAdapter.lastNameSearch(LogInUserControl.Username);

            //Logged in user's employee number
            Int32 employeeNumber = (Int32)this.user_CredentialTableAdapter.empNumberSearch(LogInUserControl.Username);
            

            //Set label texts in homeUserControl to the values above
            StoreInventoryNumber.Text = numberOfRows + "\n Products";
            lowStockLabel.Text = lowStockRows + "\n Products";
            welcomeUserLabel.Text = "Welcome " + " " +
                firstName + " " + lastName + " " + employeeNumber.ToString() + ".";
        }
    }
}
